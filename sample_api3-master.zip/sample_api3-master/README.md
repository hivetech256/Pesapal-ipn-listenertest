A sample PHP integration consuming Pesapal API3

Download the zip file or git clone the project into your root forder to run it in your browser. E.g using the windows wampserver, the root path for the project would be /c/wamp64/www. Then on the browser you would access it as http://localhost/sample_api3/

For Pesapal API3 documentation reference, use the link below.

https://developer.pesapal.com/how-to-integrate/api-30-json/api-reference
