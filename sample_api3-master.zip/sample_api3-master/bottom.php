</div>
            </div>
        </div>
	</section>
	
	<footer>
		<div class="pp-footmenu container">
      <div class="row-fluid">
            <div class="span9">
                 <ul class="nav nav-pills">
                    <li><a href="https://www.pesapal.com/home/aboutus">About PesaPal</a></li>
                    <li><a href="https://www.pesapal.com/home/features">Features</a></li>
                    <li><a href="https://www.pesapal.com/home/products">Discover PesaPal</a></li>
                    <li><a href="http://support.pesapal.com/" target="_blank">Support</a></li>
                    <li><a href="https://www.pesapal.com/home/contactus">Contact PesaPal</a></li>
                </ul>
            </div>
            <div class="social span3">
				<a target="_blank" href="http://www.facebook.com/pages/Pesapal/122585957766795" style="margin: 3px;">
                	<img title="Follow us on Facebook" alt="Facebook" src="images/ic-facebook.png">
            	</a>
				<a target="_blank" href="https://twitter.com/pesapal" style="margin: 3px;">
                	<img title="Follow us on Twitter" alt="Twitter" src="images/ic-twitter.png">
            	</a>
				<a target="_blank" href="http://www.youtube.com/user/pesapal" style="margin: 3px;">
                	<img title="Follow us on Youtube" alt="Youtube" src="images/ic-youtube.png">
            	</a>
            </div>
        </div>
    </div>
	
	<div class="footer">
	<div class="pp-footsummary container">
        <div class="media row-fluid">
			<p class="span2 text-center">
				<a href="http://www.forbes.com/sites/mfonobongnsehe/2012/02/13/top-20-tech-startups-in-africa/2/" target="_blank">
					<img src="http://localhost/pesapal3/images/news.png" title="Forbes Africa" alt="Forbes Africa"></a>
			</p>
			<p class="span2 text-center">
				<a href="http://www.businessinsider.com/20-hot-international-startups-you-need-to-watch-2011-9#pesapal-is-the-paypal-of-kenya-13" target="_blank">
					<img src="http://localhost/pesapal3/images/news2.png" title="Business Insider" alt="Business Insider"></a>
			</p>
			<p class="span4 text-center">
			   <a href="http://www.itnewsafrica.com/2012/03/top-ten-tech-start-ups-in-africa/" target="_blank">
					<img src="http://localhost/pesapal3/images/news3.png" title="IT News Africa" alt="IT News Africa"></a>
			</p>
			<p class="span4 text-center">
				<a href="http://www.businessdailyafrica.com/Corporate-News/Telkom-Kenya-inks-deal-with-PesaPal-for-airtime-service/-/539550/1660342/-/shtalk/-/index.html" target="_blank">
					<img src="http://localhost/pesapal3/images/news4.png" title="Business Daily" alt="Business Daily"></a>
			</p>
      	</div>
        <div class="smmenu row-fluid">
            <div class="span2 bdr">
              <h5><a href="https://www.pesapal.com/home/index.html">Consumers</a></h5>
                <ul>
					<li><a href="https://www.pesapal.com/billpayments">Pay your bill</a></li>
					<li><a href="https://www.pesapal.com/schoolpay">Pay School Fees </a></li>
					<li><a href="https://www.pesapal.com/buy/airtime">Buy Airtime</a></li>
					<li><a href="https://www.pesapal.com/buy/tickets">Buy Event Tickets </a></li>
					<li><a href="https://www.pesapal.com/buy/directory">Find places to shop </a></li>
                </ul>
              </div>
            <div class="span2 bdr">
              <h5><a href="https://www.pesapal.com/home/business.html">Businesses</a></h5>
                <ul>
					<li><a href="https://www.pesapal.com/products/ecommerce">Accept Online Payments</a></li>
					<li><a href="https://www.pesapal.com/products/invoices">Online invoicing</a></li>
					<li><a href="https://www.pesapal.com/products/schoolpay">Simpleselling</a></li>
					<li><a href="https://www.pesapal.com/products/eventtickets">Sell event tickets</a></li>
					<li><a href="https://www.pesapal.com/account/merchantregister">Register yor business</a></li>
				</ul>
              </div>
            <div class="span2 bdr">
                    <h5><a href="http://developer.pesapal.com/" target="_blank">Developers</a></h5>
                	<ul>
						<li><a href="http://developer.pesapal.com/" target="_blank">Developers Area</a></li>
						<li><a href="http://developer.pesapal.com/how-to-integrate/step-by-step" target="_blank">Intergrate PesaPal</a></li>
						<li><a href="http://developer.pesapal.com/forum/4-plugins" target="_blank">Download Plugins</a></li>
						<li><a href="http://developer.pesapal.com/forum" target="_blank">Ask a question</a></li>
						<li><a href="http://developer.pesapal.com/integration-partners" target="_blank">Intergration Partners</a></li>
                	</ul>
              </div>
                <div class="span4 bdr">
                    <h5><a href="">Talk to us</a></h5>
                    <div class="row-fluid">
                    	<p class="span6">
                        	PesaPal Limited <br>
                   	    	Dagoretti Lane <br>
							Off Naivasha Road<br> 
                   	    	P.O Box 1179-00606<br>
							Nairobi, Kenya 
                        </p>
                      <p class="span6"> 
                        <strong>Tel</strong> +254-(0)70-619-1729, +254-(0)202-495-438 
                       	  <br>
                   	    <strong>Email</strong>: <a href="mailto:info@pesapal.com">info@pesapal.com</a> </p>
                    </div>
                </div>
               <div class="span2">
                	<h5><a href="https://www.pesapal.com/security">Security</a></h5>
					<ul>
                        <li><a href="https://www.pesapal.com/home/termsandconditions">Terms and Conditions</a></li>
                        <li><a href="https://www.pesapal.com/home/privacypolicy">Privacy Policy</a></li>
						 <li><a href="https://www.pesapal.com/security">PesaPal Security</a></li>
                    </ul>
					
                </div>
            </div>
            <p class="pp-copyright">
            	©2013 PesaPal™. All rights reserved
            </p>
        </div>
	</div>
	</footer>
		
    <p style="display: none;" id="back-top">
        <a href="#top"><span></span></a>
    </p>
    </div>
    <a href="mailto:developer@pesapal.com">
    	<img src="images/feedback.png" alt="feedback" class="feedback">
    </a>
    </div>
    </div>      
    <script src="js/bootstrap.js"></script>
    <script src="js/jquery.js"></script>
  	<script src="js/pp.js"></script><style id="jPanelMenu-style-master">body{width:100%}.jPanelMenu,body{overflow-x:hidden}#jPanelMenu-menu{display:block;position:fixed;top:0;left:0;height:100%;z-index:-1;overflow-x:hidden;overflow-y:hidden;-webkit-overflow-scrolling:touch}.jPanelMenu-panel{position:static;left:0;top:0;z-index:2;width:100%;min-height:100%;background:rgb(255, 255, 255)}</style>


</body></html>